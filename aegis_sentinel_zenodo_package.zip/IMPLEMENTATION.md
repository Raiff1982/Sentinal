# IMPLEMENTATION

## Wire Protocol: JSON-Lines over stdio
- One UTF-8 JSON object per line (NDJSON)
- No BOM; newline terminates each message; newline is **not** part of the MAC
- Keys sorted; separators: (',', ':')

### Request
{
  "id": "uuid",
  "stage": "TASK|ANALYSIS|DRAFT|ETHICS",
  "payload": { ... },
  "ts": 1730265600,
  "sig": "HMAC-SHA256(hex) over canonical payload"
}

### Response
{
  "id": "uuid",
  "status": "OK|ERROR",
  "result": { ... },     // if OK
  "error":  { "code": "ENUM", "msg": "..." }, // if ERROR
  "sig": "HMAC-SHA256(hex) over canonical result"
}

## Canonicalization for HMAC
- JSON dump with sorted keys and separators (',', ':')
- UTF-8 bytes
- Algorithm: HMAC-SHA256 with 32-byte key from env `NEXUS_HMAC_KEY_HEX` (hex)

## Error Codes
- PAYLOAD_TOO_LARGE
- HIGH_ENTROPY
- SENSITIVE_MARKER
- BAD_MAC
- CANONICAL_MISMATCH
- INTERNAL_ERROR

## Test Vectors
Key (hex):
00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff

Payload A:
{"metrics":{"l2_norm":0.0,"n_tokens":3},"sentiment":{"score":-0.5},"stage":"ANALYSIS"}
HMAC:
c0d71b927ec003e48f918fdba0060e21f9e6c10061fb3adbcebfb86670c46541

Payload B:
{"artifacts":{"deterministic_artifact_3x3":[[1,2,3],[4,5,6],[7,8,9]]},"draft":"Creative summary: A concerned synthesis of 4200 tokens. Signal suggests sentiment=-0.620. Focus: clear benefits, documented risks, and actionable steps.","stage":"DRAFT"}
HMAC:
bb370b8ed71d99b0416c0f1a4cb8ca8a34e1f6475e6ba57fc43b6542b1855270

## Security Notes
- Prototype; not production-hardened
- Run demos in a sandbox VM for **reproducibility and isolation**, not because of known malware
- Prefer single-language pipeline in this iteration (Python), keep cross-lang wire spec for future Ada/WASI module
