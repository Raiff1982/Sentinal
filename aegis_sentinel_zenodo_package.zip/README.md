# Aegis Sentinel — Ethical Security Cortex (Zenodo Package)

**Date:** 2025-08-29

This archive packages:
- A cleaned architecture PDF and diagram
- The improved README PDF
- Implementation spec (wire format, HMAC canonicalization, error codes)
- Agent descriptions and decision rules
- Benchmark skeleton + CSV headers
- A small test corpus (JSONL) with allow/deny/edge cases
- Checksums and a changelog documenting how we got here (including earlier misspellings like "Sentinal")

We intentionally include artifacts that reflect the project's evolution to preserve provenance.

## Contents
- `docs/Aegis_Sentinel_Architecture.pdf`
- `docs/Project_SENTINAL_Readme.pdf` (historical — note spelling)
- `docs/aegis_architecture_diagram.png`
- `IMPLEMENTATION.md`
- `AGENTS.md`
- `BENCHMARKS.md`
- `CHANGELOG.md`
- `checksums/MD5SUMS.txt`
- `corpus/test_corpus.jsonl`

## License
Unless otherwise noted in file headers, content is released under **CC BY 4.0**.

## Citation
Harrison, J. (2025). Project Sentinel. Zenodo. https://doi.org/10.5281/zenodo.16998218
