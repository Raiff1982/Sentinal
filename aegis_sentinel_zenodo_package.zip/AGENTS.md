# AGENTS

## Risk Detector
- Inputs: text, domains, entropy
- Rules: sensitive markers, deny-list domains, entropy threshold, size
- Output: {"risks":[...], "severity":0..1}

## Temporal Coherence
- Inputs: timestamps, TTL, prior decisions
- Rules: decay stale signals, TTL enforcement
- Output: {"temporal_ok": true/false, "reasons":[...]}

## Ethics/Virtue
- Inputs: draft text
- Rules: ban absolutism; require sources when phrase "actionable steps" appears; redact sensitive tokens
- Output: {"ethics_ok": true/false, "issues":[...]}

## Meta-Judge
- Inputs: all agent outputs
- Method: weighted voting (risk > ethics > temporal); ties → conservative ("REVISION_REQUIRED")
- Output: {"decision":"APPROVED|REVISION_REQUIRED|BLOCKED"}

### Config Knobs
- entropy_threshold_bits_per_char (default 5.5)
- sensitive patterns (SSN, password, private key, mnemonic, seed phrase)
- domain allow/deny logic (exact or dot-boundary suffix)
- weights for Meta-Judge
