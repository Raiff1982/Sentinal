# CHANGELOG

## 2025-08-29
- Rename project to **Aegis Sentinel** (fix "Sentinal" misspelling)
- Added architecture PDF + diagram
- Added IMPLEMENTATION.md with JSON-Lines spec & HMAC vectors
- Added AGENTS.md and BENCHMARKS.md skeleton
- Packed historical README PDF to preserve provenance
- Provided test corpus and checksums

## Earlier
- Mixed-language experiments (Ada/Python/binary)
- Prototype guardrails and multi-agent arbitration concepts
