# BENCHMARKS

## Goal
Report latency/throughput for each stage on a fixed corpus.

## Machine Spec (example)
- CPU: 8-core x86_64
- RAM: 16 GB
- OS: Ubuntu 22.04
- Python: 3.11.x

## Corpus
- 10,000 inputs
  - 70% benign
  - 20% blocked (entropy/sensitive)
  - 10% edge (near limits)

## Metrics (per stage)
- p50, p90, p99 latency (ms)
- Throughput (msgs/min)
- RSS memory (MB)
- Error counts

## CSV Headers
timestamp_iso,stage,latency_ms,cpu_pct,rss_mb,status,error_code

## How to Run (example)
python tools/runner.py --input corpus/test_corpus.jsonl --log logs/run.jsonl --out metrics.csv
